<?php 
register_nav_menus(
    array('primary-menu'=>'Header Menu')
)

?>
