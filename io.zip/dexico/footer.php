<div class="container-fluid">
        <div class="row"id="footer_img" style="margin-bottom: 15px;margin-left: 3rem;">
            <div class="row g-2 my-2">
                <div class="col-7"><h3 class="footer_h">A special and qualified service dedicated to luxury properties for rent</h3></div>
                <div class="col-3 dexico">dexico</div>
            </div>
            <div class="row g-3 my-2">
                <div class="col"><ul>
                    <li><a href="" class="footer_a">– Propertys</a></li>
                    <li><a href="" class="footer_a">– Agents</a></li>
                    <li><a href="" class="footer_a">– Locations</a></li>
                    <li><a href="" class="footer_a">– Clients Support</a></li>
                </ul></div>
                <div class="col"><ul>
                    <li><a href="index.html" class="footer_a">– Home</a></li>
                    <li><a href="about.html" class="footer_a">– About</a></li>
                    <li><a href="blog.html" class="footer_a">– Blog</a></li>
                    <li><a href="contacts.html" class="footer_a">– Contacts</a></li>
                </ul></div>
                <div class="col">
                    <ul>
                    <li><spanf><i class="bx bxs-map icon "style="font-size:x-large;color:rgb(7, 115, 115)"></spanf></i><spanf>
                        LA, Vehicula Street , 58</spanf></li>
                    <li><spanf><i class="bx bxs-phone icon "style="font-size:x-large;color:rgb(7, 115, 115)"></span></i><spanf>
                        + 123 6897 8974</spanf></li>
                    <li><spanf><i class="bx bxs-envelope icon "style="font-size:x-large;color:rgb(7, 115, 115)"></span></i><spanf>hello@merkulov.design</spanf></li>
                    <i class="bx-fw bx bxl-twitter bx-sm" style="color: #3c6e71;"></i>
                        <i class="bx-fw bx bxl-facebook bx-sm" style="color: #3c6e71;"></i>
                        <i class="bx-fw bx bxl-instagram bx-sm" style="color: #3c6e71;"></i>
                    <li><spanf><i class="bx bxs-facebook icon " style="font-size:x-large;color:rgb(7, 115, 115)"></span></i><span></span></li>
                   </ul>
               </div>
            </div>
            <hr >
            <center>Merkulove © Dexico Template All rights reserved Copyrights 2020</center>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF"
        crossorigin="anonymous"></script>